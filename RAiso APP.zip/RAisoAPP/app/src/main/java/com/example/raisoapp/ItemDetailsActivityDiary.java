package com.example.raisoapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailsActivityDiary extends AppCompatActivity {

    private TextView itemName, itemPrice, itemStock, buyErrorMsg;
    private ImageView itemImage;
    private EditText quantityTextField;
    private Button buyButton;
    private String price = "Rp. 15000"; // Example price

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items_detail_pensil);

        // Initialize views
        itemName = findViewById(R.id.itemName);
        itemPrice = findViewById(R.id.itemPrice);
        itemStock = findViewById(R.id.itemStock);
        itemImage = findViewById(R.id.itemImage);
        quantityTextField = findViewById(R.id.quantityTextField);
        buyErrorMsg = findViewById(R.id.buyErrorMsg);
        buyButton = findViewById(R.id.buyButton);

        // Set item details
        itemName.setText("Diary Merah");
        itemPrice.setText(price);
        itemStock.setText("Tersedia, 100 stock lagi");
        itemImage.setImageResource(R.drawable.image5); // Replace with actual image

        // Set buy button listener
        buyButton.setOnClickListener(v -> buyItem());

        buyButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    buyButton.setBackgroundColor(0xFF02A7F0); // Change to darker color
                    break;
                case MotionEvent.ACTION_UP:
                    buyButton.setBackgroundColor(0xFFF59A23); // Revert to original color
                    break;
            }
            return false;
        });

        // Back button click listener
        findViewById(R.id.backLabel).setOnClickListener(view -> navigateToItemsPage());
        findViewById(R.id.backIcon).setOnClickListener(v -> navigateToItemsPage());
    }

    private void buyItem() {
        String quantityStr = quantityTextField.getText().toString();

        if (TextUtils.isEmpty(quantityStr)) {
            showErrorMsg("Jumlah pembelian harus diisi.");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            showErrorMsg("Jumlah pembelian harus berupa angka.");
            return;
        }

        if (quantity <= 0) {
            showErrorMsg("Jumlah pembelian harus lebih dari 0.");
            return;
        }

        // If validation passes, proceed with purchase
        Toast.makeText(this, "Transaksi berhasil! Mengarahkan ke halaman item...", Toast.LENGTH_LONG).show();

        // Show success dialog
        showSuccessDialog();

        // Navigate back to items page after purchase
        navigateToItemsPage();
    }

    private void showErrorMsg(String msg) {
        buyErrorMsg.setText(msg);
        buyErrorMsg.setVisibility(View.VISIBLE);
    }

    private void showSuccessDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Transaction Success!")
                .setMessage("Your purchase was successful.")
                .setPositiveButton("OK", (dialog, which) -> {
                    dialog.dismiss();
                })
                .show();
    }

    public void navigateToItemsPage() {
        Intent intent = new Intent(this, ItemsPageActivity.class);
        startActivity(intent);
        finish();
    }
}
